package com.cesar.SistemaDeEncuestasBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaDeEncuestasBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
