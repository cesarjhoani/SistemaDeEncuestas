package com.cesar.SistemaDeEncuestasBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaDeEncuestasBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaDeEncuestasBackendApplication.class, args);
	}

}
